package com.example.contactapp.db

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "phoneCatalog")


//TO TABLE ΠΟΥ ΘΑ ΓΙΝΟΝΤΕ SAVE Η ΚΑΘΕ ΕΠΑΦΗ
data class Data(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    @ColumnInfo (name = "first_name") val firstName : String,
    @ColumnInfo (name = "last_name") val lastName : String,
    @ColumnInfo (name = "number") val number : String,
    @ColumnInfo (name = "email") val email : String,
):Serializable // ΜΕΤΑΤΡΟΠΗ ΣΕ BYTE STREAM ΓΙΑ ΤΗΝ ΜΕΤΑΦΟΡΑ ΤΩΝ ΔΕΔΟΜΕΝΩΝ