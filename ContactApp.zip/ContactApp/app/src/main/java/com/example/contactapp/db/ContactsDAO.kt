package com.example.contactapp.db

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao

interface ContactsDAO {
    @Query("SELECT * FROM phoneCatalog ORDER BY first_name ASC") //ΕΠΙΛΕΓΟΥΜΕ ΟΛΟ ΤΟ CATALOG
    fun getAllCatalog(): LiveData<List<Data>>

    @Query("SELECT * FROM phoneCatalog WHERE id = :id") //ΕΠΙΛΕΓΟΥΜΕ ΕΝΑ SPECIFIED ΑΠΟΘΗΚΕΥΜΕΝΗ ΕΠΑΦΗ ΑΠΟ ΤΟ ID
    fun getCatalogById(id: Int): LiveData<Data>

    @Query("SELECT * FROM phoneCatalog WHERE first_name LIKE :firstName OR last_name LIKE :lastName")
    suspend fun searchContact(firstName: String, lastName: String): List<Data> // ΓΙΑ ΤΗΝ ΑΝΑΖΥΤΗΣΗ ΕΠΑΦΗΣ (searchbar)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertContact(data: Data) // ΓΙΑ ΝΑ ΠΡΟΣΘΕΣΟΥΜΕ ΝΕΑ ΕΠΑΦΗ

    @Update
    suspend fun updateContact(data: Data) // ΝΑ ΑΛΛΑΞΟΥΜΕ ΚΑΙ ΝΑ ΚΑΝΟΥΜΕ UPDATE ΚΑΠΟΙΑ ΣΤΟΙΧΕΙΑ ΤΙΣ ΕΠΑΦΗΣ

    @Delete
    suspend fun deleteContact(data: Data) // ΝΑ ΔΙΑΓΡΑΨΟΥΜΕ ΤΗΝ ΕΠΑΦΗ
}