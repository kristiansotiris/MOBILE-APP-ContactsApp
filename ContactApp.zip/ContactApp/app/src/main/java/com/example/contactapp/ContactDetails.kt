package com.example.contactapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.contactapp.db.Data
import com.example.contactapp.viewmodels.ContactsViewModel
import com.example.contactapp.viewmodels.ViewModelFactory

class ContactDetails : AppCompatActivity() {

    private val contactsViewModel: ContactsViewModel by viewModels {
        ViewModelFactory(application)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contact_details)

        // Adjust window insets for layout padding
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.contact_details_layout)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        //ΠΑΙΡΝΟΥΜΕ ΤΙΣ ΠΛΗΡΟΦΟΡΙΕΣ ΜΕΣΑ ΑΠΟ ΤΟ ID ΠΟΥ ΔΗΛΩΣΑΜΕ ΣΤΟ CONTACT ADAPTER ΜΕ ΤΗΝ GET INT EXTRA
        val contactId = intent.getIntExtra("contactId", -1)

        // ΑΡΧΙΚΟΠΟΙΟΥΜΕ ΤΑ TEXT EDITS TEXT ΓΙΑ ΤΙΣ ΠΛΗΡΟΦΟΡΙΕΣ ΤΟΥ ΧΡΗΣΤΗ
        val firstNameTextView: TextView = findViewById(R.id.firstNameEditText)
        val lastNameTextView: TextView = findViewById(R.id.lastNameEditText)
        val phoneNumberTextView: TextView = findViewById(R.id.phoneNumberEditText)
        val emailTextView: TextView = findViewById(R.id.emailEditText)

        //ΕΛΕΧΓΟΥΜΕ ΕΑΝ ΕΙΝΑΙ ΣΩΣΤΗ Η ΕΠΑΦΗ ΠΟΥ ΕΠΕΛΕΞΕ Ο ΧΡΗΣΤΗΣ
        if (contactId != -1) {
            //ΜΕ ΤΗΝ ΜΕΘΟΔΟ OBSERVE ΠΟΥ ΕΦΑΡΜΟΖΕΤΑΙ ΑΠΟ ΤΗΝ LIVEDATA ΕΝΗΜΕΡΩΝΕΤΕ ΤΟ ΔΕΔΟΜΕΝΑ ΤΟΥ ΧΡΗΣΤΗ
            contactsViewModel.getContactById(contactId).observe(this) { contact ->
                //ΕΝΗΜΕΡΩΝΟΝΕΤΕ ΤΟ UI ΜΕ ΤΙΣ ΠΛΗΡΟΦΟΡΙΕΣ ΤΟΥ ΧΡΗΣΤΗ ΜΕΣΟ ΤΟΥ VIEWMODEL
                if (contact != null) {
                    firstNameTextView.text = contact.firstName
                    lastNameTextView.text = contact.lastName
                    phoneNumberTextView.text = contact.number
                    emailTextView.text = contact.email
                }
            }
        }

        //ΜΕΘΟΔΟΣ ΓΙΑ ΤΗΝ ΕΝΗΜΕΡΩΣΗ ΠΛΗΡΟΦΟΡΙΩΝ ΤΟΥ ΧΡΗΣΤΗ ΟΤΑΝ Ο ΧΡΗΣΤΗΣ ΔΗΛΑΔΗ ΚΑΝΕΙ ΚΑΠΟΙΑ ΑΛΛΑΓΗ ΣΤΑ ΠΑΙΔΙΑ FIRSTNAME LASTNAME EMAIL PHONE
        val updateButton: Button = findViewById(R.id.updateButton)
        updateButton.setOnClickListener {
            // ΠΑΙΡΝΟΥΜΕ ΤΑ ΠΕΔΙΑ ΤΟΥ EDIT TEXT
            val updatedFirstName = firstNameTextView.text.toString()
            val updatedLastName = lastNameTextView.text.toString()
            val updatedPhoneNumber = phoneNumberTextView.text.toString()
            val updatedEmail = emailTextView.text.toString()

            //ΕΛΕΧΓΟΣ ΓΙΑ ΤΑ ΠΕΔΙΑ ΕΑΝ ΔΕΝ ΕΙΝΑΙ ΚΕΝΑ
            if(updatedFirstName.isNotEmpty() && updatedLastName.isNotEmpty() && updatedPhoneNumber.isNotEmpty() && updatedEmail.isNotEmpty()){

                val updatedContact = Data(contactId, updatedFirstName, updatedLastName, updatedPhoneNumber, updatedEmail)
                contactsViewModel.update(updatedContact)
                Toast.makeText(this, "Contact updated successfully", Toast.LENGTH_SHORT).show()

                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)

                finish()
            }else{
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            }
        }


        // ΜΕΘΟΔΟΣ ΓΙΑ ΤΟ ΚΟΥΜΠΙ ΤΙΣ ΔΙΑΓΡΑΦΗΣ ΕΠΑΦΗΣ ΤΟΥ ΧΡΗΣΤΗ
        val deleteButton: Button = findViewById(R.id.deleteButton)
        deleteButton.setOnClickListener {
            Toast.makeText(this, "Deleting the Contact...", Toast.LENGTH_SHORT).show()

            val contactToDelete = Data(contactId, firstNameTextView.text.toString(), lastNameTextView.text.toString(), phoneNumberTextView.text.toString(), emailTextView.text.toString())
            contactsViewModel.delete(contactToDelete)
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
            Toast.makeText(this, "Contact deleted successfully", Toast.LENGTH_SHORT).show()
        }
    }
}
