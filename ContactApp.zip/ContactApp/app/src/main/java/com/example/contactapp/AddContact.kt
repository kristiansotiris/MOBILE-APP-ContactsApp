package com.example.contactapp
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.ViewModelProvider
import com.example.contactapp.db.Data
import com.example.contactapp.viewmodels.ContactsViewModel
import com.example.contactapp.viewmodels.ViewModelFactory

class AddContact : AppCompatActivity() {

    private lateinit var contactsViewModel: ContactsViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_add_contact)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // ΑΡΧΙΚΟΠΟΙΟΥΜΕ ΤΗΝ ViewModelFACTORY ΓΙΑ ΤΗΝ ViewModel
        val viewModelFactory = ViewModelFactory(application)

        // ΑΡΧΙΚΟΠΟΙΟΥΜΕ ΤΗΝ ViewModel ΜΕ ΤΗΝ ViewModelPROVIDER
        contactsViewModel = ViewModelProvider(this, viewModelFactory)[ContactsViewModel::class.java]

        // ΑΡΧΙΚΟΠΟΙΟΥΜΕ ΤΑ ΠΕΔΙΑ ΤΟΥ EDITTEXT
        val firstNameEditText: EditText = findViewById(R.id.firstNameEditText)
        val lastNameEditText: EditText = findViewById(R.id.lastNameEditText)
        val numberEditText: EditText = findViewById(R.id.phoneNumberEditText)
        val emailEditText: EditText = findViewById(R.id.emailEditText)
        val saveButton: Button = findViewById(R.id.saveContactButton)

        // ΜΕΘΟΔΟΣ ΓΙΑ ΤΗΝ ΑΠΟΘΗΚΕΥΣΗ ΝΕΑΣ ΕΠΑΦΗΣ ΣΤΗΝ ΒΔ
        saveButton.setOnClickListener {
            val firstName = firstNameEditText.text.toString().trim()
            val lastName = lastNameEditText.text.toString().trim()
            val phoneNumber = numberEditText.text.toString().trim()
            val email = emailEditText.text.toString().trim()

            // ΕΛΕΧΓΟΣ ΓΙΑ ΝΑ ΜΗΝ ΕΧΟΥΜΕ ΚΕΝΑ ΠΕΔΙΑ
            if (firstName.isNotEmpty() && lastName.isNotEmpty() && phoneNumber.isNotEmpty() && emailEditText.text.isNotEmpty()) {

                //ΔΗΜΙΟΥΡΓΙΑ ΤΙΣ ΝΕΑΣ ΕΠΑΦΗΣ
                val newContact = Data(firstName = firstName, lastName = lastName, number = phoneNumber, email = email)

                // ΑΠΟΘΗΚΕΥΣΗ ΤΗΣ ΝΕΑΣ ΕΠΑΦΗΣ ΣΤΗ ΒΑΣΗ ΔΕΔΟΜΕΝΩΝ ΜΕ ΤΗΝ ΙΝΣΕΡΤ
                contactsViewModel.insert(newContact)

                Toast.makeText(this, "Contact added successfully!", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(this, "Please fill in all fields.", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
