package com.example.contactapp

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.widget.SearchView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.contactapp.adapter.ContactAdapter
import com.example.contactapp.viewmodels.ContactsViewModel
import com.example.contactapp.viewmodels.ViewModelFactory
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {

    // ΔΗΛΩΝΟΥΜΕ ΤΟ ViewModel ΚΑΙ ΤΗΝ ADAPTER ΣΤΗ MainActivity
    private lateinit var contactsViewModel: ContactsViewModel
    private lateinit var contactAdapter: ContactAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // ΑΡΧΙΚΟΠΟΙΗΣΗ ViewModel
        val viewModelFactory = ViewModelFactory(application)
        contactsViewModel = ViewModelProvider(this, viewModelFactory)[ContactsViewModel::class.java]

        val addContactButton: FloatingActionButton = findViewById(R.id.addContact)
        val contactRecyclerView: RecyclerView = findViewById(R.id.contactRecyclerView)

        // ΕΦΑΡΜΟΖΟΥΜΕ ΤΟ LAYOUT MANAGER ΣΤΗ Recyclerview
        contactRecyclerView.layoutManager = LinearLayoutManager(this)

        // ΕΦΑΡΜΟΖΟΥΜΕ ΤΗΝ ContactAdapter ΣΤΗ Recyclerview ΜΕ ΜΙΑ ΚΕΝΗ ΛΙΣΤΑ
        contactAdapter = ContactAdapter(mutableListOf())
        contactRecyclerView.adapter = contactAdapter

        //ΜΕ ΑΥΤΗΝ ΤΗΝ ΜΕΘΟΔΟ ΟΤΑΝ ΓΙΝΕΤΕ ΚΑΠΟΙΑ ΑΛΛΑΓΗ Η ΚΑΠΟΙΑ ΕΝΗΜΕΡΩΣΗ ΤΙΣ ΕΠΑΦΗΣ Η ΚΑΠΟΙΑ ΠΡΟΣΘΙΚΗ ΝΕΑΣ ΕΠΑΦΗΣ ΤΟΤΕ
        //ΓΙΝΕΤΕ UPDATED ΜΕ ΤΗΝ ΜΕΘΟΔΟ UPDATEDCONTACTS ΚΑΙ ΜΕ ΟΛΟ  ΑΥΤΟ ΠΑΡΑΚΟΛΟΥΘΟΥΜΕ ΤΑ ΔΕΔΟΜΕΝΑ ΤΙΣ LIVEDATA ΑΠΟ ΤΟ VIEWMODEL
        contactsViewModel.allContacts.observe(this) { contacts ->
            contactAdapter.updateContacts(contacts)
        }

        // ΡΥΘΜΙΖΟΥΜΕ ΤΗΝ ΑΝΑΖΥΤΗΣΗ ΕΠΑΦΩΝ ΜΕ ΒΑΣΗ ΤΟ ΟΝΟΜΑ Η ΤΟ ΕΠΩΝΥΜΟ
        val searchView: SearchView = findViewById(R.id.searchView)
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                val filteredList = contactsViewModel.allContacts.value?.filter {
                    it.firstName.contains(newText ?: "", ignoreCase = true) ||
                            it.lastName.contains(newText ?: "", ignoreCase = true)
                }
                contactAdapter.updateContacts(filteredList ?: emptyList()) // ΕΝΗΜΕΡΩΣΗ ΤΟΥ ΦΙΛΤΡΑΡΙΣΜΑΤΟΣ ΜΕ ΒΑΣΗ ΤΟ ΟΝΟΜΑ Η ΤΟ ΕΠΩΝΥΜΟ ΠΟΥ ΒΑΛΑΜΕ
                return true
            }
        })

        //ΕΙΝΑΙ ΤΟ ΚΟΥΜΠΙ ΓΙΑ ΤΗΝ ΜΕΤΑΦΟΡΑ ΤΟΥ ΧΡΗΣΤΗ ΣΕ ΕΝΑ ΑΛΛΟ EMPTY VIEW ACTIVITY ΟΠΟΥ ΜΕΤΑΦΕΡΕΤΕ ΣΤΟ ADD CONTACT
        addContactButton.setOnClickListener {
            val intent = Intent(this, AddContact::class.java)
            startActivity(intent)
        }
    }
}
