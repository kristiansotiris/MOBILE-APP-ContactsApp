package com.example.contactapp.adapter

import android.annotation.SuppressLint
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.contactapp.ContactDetails
import com.example.contactapp.R
import com.example.contactapp.db.Data

class ContactAdapter(private var contactList: MutableList<Data>) : RecyclerView.Adapter<ContactAdapter.ContactViewHolder>() {

    // ΧΡΗΣΗ ΤΟΥ VIEWMODEL / VIEW
    inner class ContactViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val contactName: TextView = itemView.findViewById(R.id.contactName)
        private val contactPhoneNumber: TextView = itemView.findViewById(R.id.contactPhoneNumber)
        private val detailsButton: Button = itemView.findViewById(R.id.details)

        @SuppressLint("SetTextI18n")
        fun bind(contact: Data) {
            contactName.text = "${contact.firstName} ${contact.lastName}"
            contactPhoneNumber.text = contact.number

            // ΜΕΘΟΔΟΣ ΓΙΑ ΤΗΝ ΛΕΠΤΟΜΕΡΗ ΔΙΑΧΗΡΗΣΗ
            detailsButton.setOnClickListener {
                val context = itemView.context
                val intent = Intent(context, ContactDetails::class.java).apply {
                    putExtra("firstName", contact.firstName)
                    putExtra("lastName", contact.lastName)
                    putExtra("phoneNumber", contact.number)
                    putExtra("email", contact.email)
                    putExtra("contactId", contact.id)
                }
                context.startActivity(intent)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContactViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.item_contact, parent, false)
        return ContactViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ContactViewHolder, position: Int) {
        val currentContact = contactList[position]
        holder.bind(currentContact)
    }

    override fun getItemCount(): Int {
        return contactList.size
    }

    // ΜΕΘΟΔΟΣ ΓΙΑ ΤΗΝ ΕΝΗΜΕΡΩΣΗ ΑΛΛΑΓΩΝ ΣΤΗ ContactList
    @SuppressLint("NotifyDataSetChanged")
    fun updateContacts(newContactList: List<Data>) {
        contactList.clear()
        contactList.addAll(newContactList)
        notifyDataSetChanged()
    }
}
