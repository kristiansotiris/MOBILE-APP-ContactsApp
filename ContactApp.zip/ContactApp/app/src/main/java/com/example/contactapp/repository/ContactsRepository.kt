package com.example.contactapp.repository

import androidx.lifecycle.LiveData
import com.example.contactapp.db.ContactsDAO
import com.example.contactapp.db.Data

class ContactsRepository(private val contactsDAO: ContactsDAO) {
    // LiveData ΑΠΟ ΤΟ all-contacts ΤΟΥ DAO
    val allContacts: LiveData<List<Data>> = contactsDAO.getAllCatalog()

    // INSERT ΜΕΘΟΔΟΣ
    suspend fun insert(data: Data) {
        contactsDAO.insertContact(data)
    }

    // Update ΜΕΘΟΔΟΣ
    suspend fun update(data: Data) {
        contactsDAO.updateContact(data)
    }

    // Delete ΜΕΘΟΔΟΣ
    suspend fun delete(data: Data) {
        contactsDAO.deleteContact(data)
    }

    //ΕΠΙΛΟΓΗ ΤΗΣ ΕΠΑΦΗΣ ΜΕΣΟ ΤΟΥ ID
     fun getContactById(id: Int): LiveData<Data> {
        return contactsDAO.getCatalogById(id)
    }
}
