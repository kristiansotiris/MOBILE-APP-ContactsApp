package com.example.contactapp.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.example.contactapp.db.Data
import com.example.contactapp.repository.ContactsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ContactsViewModel(application: Application, private val repository: ContactsRepository) : AndroidViewModel(application) {

    val allContacts: LiveData<List<Data>> = repository.allContacts

    fun insert(data: Data) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.insert(data)
        }
    }

    fun update(data: Data) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.update(data)
        }
    }

    fun delete(data: Data) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.delete(data)
        }
    }

    fun getContactById(id: Int): LiveData<Data> {
        return repository.getContactById(id)
    }
}
