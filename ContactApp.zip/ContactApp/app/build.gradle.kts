plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.example.contactapp"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.contactapp"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions {
        jvmTarget = "11"
    }
}

dependencies {
    // Core Libraries
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)

    // Unit Testing
    testImplementation(libs.junit)

    // Android Testing
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)

    // Room Dependencies
    implementation(libs.androidx.room.runtime)  // Room Runtime
    ksp(libs.androidx.room.compiler)            // KSP for Room
    implementation(libs.androidx.room.ktx)       // Kotlin Extensions for Room
    androidTestImplementation(libs.androidx.room.testing)  // Room Testing

    // ViewModel Dependencies
    implementation(libs.androidx.lifecycle.viewmodel.ktx)  // ViewModel KTX
    implementation(libs.androidx.lifecycle.livedata.ktx)   // LiveData KTX

    // Coroutines Dependencies (for ViewModelScope)
    implementation(libs.kotlinx.coroutines.android)

}

